# Pi0.5 sanity training on the new server

- Result: PASS
- GPU: NVIDIA RTX 6000D
- Total VRAM: 83.05 GiB
- Steps: 20 / 20
- Batch size: 1
- Precision: bfloat16 (Accelerate bf16)
- Train expert only: true
- Gradient checkpointing: true
- Freeze vision encoder: true
- Peak allocated VRAM: 12.85 GiB
- Peak reserved VRAM: 13.00 GiB
- Mean step time: 0.4727584111038595 s
- Total runtime: 131.95 s
- Initial loss: 1.4703712463378906
- Final loss: 1.9117406606674194
- All losses finite: True
- OOM: False
- Final checkpoint: PASS (`/root/autodl-tmp/VLA-Intern-Sprint/results/training/pi05_sanity_new_server/run/checkpoints/000020`)
